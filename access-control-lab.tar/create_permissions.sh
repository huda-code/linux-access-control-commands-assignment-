#!/bin/bash

# Single line comment -- starts with a # symbol

# Multiple line comment:
<<COMMENT
You can comment out multiple lines by enclosing them between the lines above and below.
COMMENT

<<COMMENT
Format for commands:

-- create a group
sudo groupadd <name of group>

-- assign user to group
sudo usermod -a -G <name of group> <user>

-- assign a group to a file
sudo chgrp <name of group> <file>

-- set permissions on a file
sudo -u <user who owns file> chmod <symbolic or octal permission set> <file>

COMMENT

# create groups


# assign users to groups


# assign a group to each file


# set permissions on each file

